import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'com-inn48';
  loginForm!: FormGroup;
  constructor() { 
  }

  ngOnInit() {

    this.loginForm = new FormGroup({
      uname: new FormControl (null, Validators.required),
      upwd: new FormControl (null, Validators.required)
  });
  }
  doLogin() {
    console.log(this.loginForm.value);
    this.loginForm.reset();
    // stop here if form is invalid
   // if (this.loginForm.invalid) {
    //    return;
   // }
}
}
