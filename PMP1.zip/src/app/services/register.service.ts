import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { Posts } from "../MyComponents/user-models/Posts";

@Injectable()
export class registerService
{
    constructor(private httpClient : HttpClient){}

    getUser():Observable <any>{
		return this.httpClient.get("https://jsonplaceholder.typicode.com/posts/1/comments")
    }

    post(createUser:Posts):Observable<any>{
        return this.httpClient.post("http://localhost:8090/user/registerUserProfile",createUser);
    }
}
