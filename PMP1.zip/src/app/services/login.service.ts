import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { User } from "../MyComponents/user-models/User";

@Injectable()
export class loginService
{
    constructor(private httpClient : HttpClient){}

    login(lgn:User):Observable<any>{
        return this.httpClient.post("http://localhost:8090/api/authenticate",lgn);
    }
}
