import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class viewissue
{
    constructor(private httpClient : HttpClient){}

    getIssue():Observable <any>{
		return this.httpClient.get("http://localhost:9001/productionissue/allissue")
    }
}