export class Viewissue {
    issuetitle: string;
    rootCause: string;
    issueDescription: string;
    comment: string;
    
}