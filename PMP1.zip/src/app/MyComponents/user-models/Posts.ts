export class Posts {
    userId: string;
    name: string;
    email: string;
    password: string;
    mobileNumber: string;
    role: string;
}
