export class Addissue {
    issuetitle: string;
    rootCause: string;
    issueDescription: string;
    comment: string;
    
}