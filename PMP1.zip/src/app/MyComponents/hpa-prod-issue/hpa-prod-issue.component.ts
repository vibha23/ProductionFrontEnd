import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
//import { Router } from '@angular/router';
import { addprodissue } from 'src/app/services/addprodissue.service';
import { viewissue } from 'src/app/services/viewissue.service';
import { Addissue } from '../user-models/Addissue';
import { Viewissue } from '../user-models/Viewissue';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-hpa-prod-issue',
  templateUrl: './hpa-prod-issue.component.html',
  styleUrls: ['./hpa-prod-issue.component.css']
})
export class HpaProdIssueComponent implements OnInit {
addissueForm!:FormGroup;
objIssue:Addissue;
listOfIssues:Viewissue[];
viewIssueForm!:FormGroup;
  constructor(private _addprodissue:addprodissue,private _viewprodissue:viewissue,private activatedRoute:ActivatedRoute,private router:Router) { }
  
  infoMessage = '';
  ngOnInit(): void {
    this.addissueForm = new FormGroup({
      issuetitle : new FormControl(null,Validators.required),
      rootCause : new FormControl(null,Validators.required),
      issueDescription : new FormControl(null,Validators.required),
      comment : new FormControl(null,Validators.required)
      
    })
    this._viewprodissue.getIssue()
    .subscribe(
      data=>
      {
this.listOfIssues = data;
      }
    );
    this.activatedRoute.queryParams
      .subscribe(params => {
        if(params.issue !== undefined && params.issue === 'true') {
            this.infoMessage = 'Issue added successfully!';
        }
      });
    
  }
  
  
  addissue(){
    console.log(this.addissueForm.value);
     var createIssue = new Addissue();
     createIssue.issuetitle=this.addissueForm.value.issuetitle;
     createIssue.rootCause=this.addissueForm.value.rootCause;
     createIssue.issueDescription=this.addissueForm.value.issueDescription;    
     createIssue.comment=this.addissueForm.value.comment;        
                    
    this._addprodissue.postIssue(createIssue)
    .subscribe(
      data=>
      {
		this.objIssue =data;
    this.router.navigate(['hpa-prod-issue'], {queryParams: { issue: 'true' }} );
    window.location.reload();
      }      
    )

  }
}
