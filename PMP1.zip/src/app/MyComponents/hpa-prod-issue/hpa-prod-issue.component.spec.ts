import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HpaProdIssueComponent } from './hpa-prod-issue.component';

describe('HpaProdIssueComponent', () => {
  let component: HpaProdIssueComponent;
  let fixture: ComponentFixture<HpaProdIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HpaProdIssueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HpaProdIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
