import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inn48',
  templateUrl: './inn48.component.html',
  styleUrls: ['./inn48.component.css']
})
export class Inn48Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
