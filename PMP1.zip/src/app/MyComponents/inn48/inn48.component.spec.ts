import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Inn48Component } from './inn48.component';

describe('Inn48Component', () => {
  let component: Inn48Component;
  let fixture: ComponentFixture<Inn48Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Inn48Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Inn48Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
