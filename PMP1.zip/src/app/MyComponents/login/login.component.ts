import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { loginService } from 'src/app/services/login.service';
import { User } from '../user-models/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;  
   objPost:User;

  
  constructor(private _loginService:loginService,private activatedRoute:ActivatedRoute,private router:Router) { }

   infoMessage = '';
  ngOnInit() {
    this.activatedRoute.queryParams
      .subscribe(params => {
        if(params.registered !== undefined && params.registered === 'true') {
            this.infoMessage = 'Dear '+params.name +' ,You have registered successfully! Please Login!';
        }
      });

    this.loginForm = new FormGroup({
      uname: new FormControl (null, Validators.required),
      upwd: new FormControl (null, Validators.required)
  });
  }
  
  doLogin() {
    console.log(this.loginForm.value);
     var user = new User();
    user.username=this.loginForm.value.uname;
    user.password=this.loginForm.value.upwd;
    this._loginService.login(user)
    .subscribe(
      data=>
      {
		this.objPost =data;
		this.router.navigate(['product-detail']);
      }
    )  
     
//    this.loginForm.reset();
    // stop here if form is invalid
   // if (this.loginForm.invalid) {
    //    return;
   // }
  }
}
