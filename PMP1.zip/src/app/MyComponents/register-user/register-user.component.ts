import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { registerService } from 'src/app/services/register.service';
import { Posts } from '../user-models/Posts';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
 registerForm!: FormGroup;
 objPost:Posts;
 
  constructor(private _registerService:registerService,private router:Router) { }

  ngOnInit(){
    this.registerForm = new FormGroup({
      name : new FormControl(null,Validators.required),
      email : new FormControl(null,[Validators.required,Validators.email]),
      cNumber : new FormControl(null,Validators.required),
      password : new FormControl(null,Validators.required),
      team : new FormControl(null,Validators.required)
    })
  }


  addUser(){
    console.log(this.registerForm.value);
     var createUser = new Posts();
    createUser.userId=this.registerForm.value.email;
    createUser.name=this.registerForm.value.name;
    createUser.email=this.registerForm.value.email;    
    createUser.password=this.registerForm.value.password;        
    createUser.mobileNumber=this.registerForm.value.cNumber;        
    createUser.role='Admin';                
    this._registerService.post(createUser)
    .subscribe(
      data=>
      {
		this.objPost =data;
		this.router.navigate(['login'], {queryParams: { registered: 'true', name: data.name } });
      }      
    )

  }
}
