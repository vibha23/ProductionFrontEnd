import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { Inn48Component } from './MyComponents/inn48/inn48.component';
import { RegisterUserComponent } from './MyComponents/register-user/register-user.component';
import { LoginComponent } from './MyComponents/login/login.component';
import { FormsModule } from '@angular/forms';
import { ProductDetailComponent } from './MyComponents/product-detail/product-detail.component';
import { registerService } from './services/register.service';
import { loginService } from './services/login.service';
import { HpaProdIssueComponent } from './MyComponents/hpa-prod-issue/hpa-prod-issue.component';
import { addprodissue } from './services/addprodissue.service';
import { viewissue } from './services/viewissue.service';


@NgModule({
  declarations: [
    AppComponent,
    Inn48Component,
    RegisterUserComponent,
    LoginComponent,
    ProductDetailComponent,
    HpaProdIssueComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path: '', component:LoginComponent},
      {path: 'login', component:LoginComponent},
      { path: 'register-user',component:RegisterUserComponent},      
      {path: 'product-detail', component:ProductDetailComponent},
      {path: 'hpa-prod-issue', component:HpaProdIssueComponent}
    ]),
  ],
  providers: [
   registerService,
   loginService,
   addprodissue,
   viewissue
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
